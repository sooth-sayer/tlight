if [[ "x$CXXTEST" -eq "x" ]]
then
    CXXTEST="../../"
fi

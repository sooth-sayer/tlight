#ifndef INCLUDE_H
#define INCLUDE_H
/**
 * @file include.h
 * Include file for this test.
 *
 * @author Gašper Ažman (GA), gasper.azman@gmail.com
 * @version 1.0
 * @since 2008-08-28 11:15:40 AM
 */

int i_need_me() {
    return 0;
}

#endif
